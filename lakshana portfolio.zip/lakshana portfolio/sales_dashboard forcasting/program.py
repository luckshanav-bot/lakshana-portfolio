
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split


def load_data(csv_path: Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    df["Order Date"] = pd.to_datetime(df["Order Date"], format="%m-%d-%Y", errors="coerce")
    df = df.dropna(subset=["Order Date"])
    return df


def prepare_monthly_sales(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["month"] = df["Order Date"].dt.to_period("M").dt.to_timestamp()
    monthly = df.groupby("month")["Sales"].sum().reset_index()
    monthly = monthly.sort_values("month").reset_index(drop=True)
    return monthly


def create_features(df: pd.DataFrame) -> pd.DataFrame:
    data = df.copy()
    data["month_num"] = data["month"].dt.month
    data["year"] = data["month"].dt.year
    data["quarter"] = data["month"].dt.quarter

    for lag in range(1, 4):
        data[f"sales_lag_{lag}"] = data["Sales"].shift(lag)

    data["rolling_mean_3"] = data["Sales"].rolling(window=3).mean()
    data = data.dropna().reset_index(drop=True)
    return data


def train_forecast(df: pd.DataFrame, forecast_periods: int = 6):
    data = create_features(df)
    features = ["month_num", "year", "quarter", "sales_lag_1", "sales_lag_2", "sales_lag_3", "rolling_mean_3"]
    X = data[features]
    y = data["Sales"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, shuffle=False
    )

    model = RandomForestRegressor(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))

    print(f"Test RMSE: {rmse:.2f}")

    last_row = df.iloc[-3:].copy()
    forecast_rows = []
    current = df.iloc[-1:].copy()

    for step in range(forecast_periods):
        next_month = current["month"].iloc[0] + pd.DateOffset(months=1)
        row = {
            "month": next_month,
            "month_num": next_month.month,
            "year": next_month.year,
            "quarter": next_month.quarter,
        }

        for lag in range(1, 4):
            if step == 0:
                row[f"sales_lag_{lag}"] = df["Sales"].iloc[-lag]
            else:
                row[f"sales_lag_{lag}"] = forecast_rows[-lag]["forecast"] if lag <= len(forecast_rows) else df["Sales"].iloc[-lag]

        row["rolling_mean_3"] = np.mean(
            [row["sales_lag_1"], row["sales_lag_2"], row["sales_lag_3"]]
        )
        features_row = np.array([row[f] for f in features]).reshape(1, -1)
        row["forecast"] = model.predict(features_row)[0]
        forecast_rows.append(row)
        current = pd.DataFrame([{"month": next_month}])

    forecast_df = pd.DataFrame(forecast_rows)
    return model, X_test, y_test, y_pred, forecast_df


def plot_results(df: pd.DataFrame, forecast_df: pd.DataFrame, y_test: pd.Series, y_pred: np.ndarray):
    plt.figure(figsize=(12, 6))
    plt.plot(df["month"], df["Sales"], label="Historical Sales", marker="o")
    plt.plot(forecast_df["month"], forecast_df["forecast"], label="Forecasted Sales", marker="x")
    plt.title("Monthly Sales and Forecast")
    plt.xlabel("Month")
    plt.ylabel("Sales")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("sales_forecast.png")
    plt.show()

    plt.figure(figsize=(10, 4))
    plt.plot(y_test.index, y_test.values, label="Actual", marker="o")
    plt.plot(y_test.index, y_pred, label="Predicted", marker="x")
    plt.title("Test Set: Actual vs Predicted Sales")
    plt.xlabel("Index")
    plt.ylabel("Sales")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("sales_forecast_test.png")
    plt.show()


def main():
    parser = argparse.ArgumentParser(description="Sales forecasting from Sales_Forecasting_project.csv")
    parser.add_argument(
        "--csv",
        type=Path,
        default=Path("Sales_Forecasting_project.csv"),
        help="Path to the CSV file",
    )
    parser.add_argument(
        "--forecast-months",
        type=int,
        default=6,
        help="Number of months to forecast",
    )
    args = parser.parse_args()

    df = load_data(args.csv)
    print("Loaded rows:", len(df))
    print(df.head())

    monthly_sales = prepare_monthly_sales(df)
    print("\nMonthly sales summary:")
    print(monthly_sales.head())

    model, X_test, y_test, y_pred, forecast_df = train_forecast(
        monthly_sales, forecast_periods=args.forecast_months
    )

    print("\nForecasted months:")
    print(forecast_df[["month", "forecast"]])

    plot_results(monthly_sales, forecast_df, y_test, y_pred)


if __name__ == "__main__":
    main()
